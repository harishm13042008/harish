# ComicCraftAI Source Code

The project document identifies these executable modules:
- app.py
- story_to_script.py
- image_generator.py
- layout_engine.py
- requirements.txt
- .env (API keys; do not upload secrets)
- README.md

Add the verified working source-code files to this folder before final GitHub submission.
