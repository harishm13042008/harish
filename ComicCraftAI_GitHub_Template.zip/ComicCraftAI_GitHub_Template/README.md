# ComicCraft AI

AI-ML and GEN-AI Track Project Template

## Team
- Team ID: SWUID2026383027
- Team Leader: Harish M
- Team Members: Bhuvanesh, Gowtham S, V Sanjay Kumar

## Phase-wise Deliverables
This repository follows the phase-wise structure of the AI-ML and GEN-AI Track Project Template.

1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing
7. Project Documentation
8. Project Demonstration

## Note
API keys and `.env` files containing secrets must not be uploaded to GitHub.
